/**
 * Zagniezdzanie funkcji.
 * Przesledz krok po kroku kazda linijke kodu. Kazda!
 * Napisz komentarze dla kazdej z linijek kodu
 */


//Twoj komentarz ...
function jeden() {

    //Twoj komentarz ...
    var zmienna1 = 1;

    //Twoj komentarz ...
    function dwa() {

        //Twoj komentarz ...
        console.log(zmienna1);

        //Twoj komentarz ...
        var zmienna2 = 3;
    }

    //Twoj komentarz ...
    dwa();

    //Twoj komentarz ...
    console.log(zmienna2)
}

//Twoj komentarz ...
jeden()