# Funkcje czasu &ndash; zadania

> Odpowiedzi wpisz w pliku **app.js**, chyba że treść polecenia wskazuje inaczej.
Pamiętaj, żeby oddzielać ćwiczenia komentarzami i pisać czytelny, dobrze sformatowany kod.

### Zadanie 1 (~ 10min - 15 min)

Napisz funkcję ```countHello()```, która jako parametr przyjmie liczbę całkowitą od 1-10. W funkcji uruchom funkcję setInterval. Niech jego zadaniem będzie wypisywanie w konsoli tekstu "Hello" oraz licznika, zliczającego, który raz już został uruchomiony setInterval.
Jeśli licznik osiągnie wartość podaną do funkcji jako parametr, powinien zostać usunięty setInterval.
