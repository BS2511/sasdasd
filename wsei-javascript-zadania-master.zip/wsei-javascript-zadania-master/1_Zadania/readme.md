

Pamiętaj o dodawaniu komentarzy z numerem zadania, np.:

```JavaScript
// Zadanie 1
{ Kod do zadania 1 }

//Zadanie 2
{ Kod do zadania 2 }

...
```

